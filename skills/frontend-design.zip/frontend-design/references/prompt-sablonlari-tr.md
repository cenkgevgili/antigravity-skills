# Frontend Design Prompt Sablonlari (TR)

Bu dosya, `$frontend-design` ile hizli ve kaliteli sonuc almak icin hazir prompt kaliplari icerir.
Kose parantezleri kendi ihtiyacina gore doldur.

## 1) Landing Page (sifirdan)

`$frontend-design [MARKA/URUN] icin sifirdan bir landing page tasarla ve kodla. Hedef kitle [HEDEF_KITLE]. Ton [TON]. Teknoloji [React/HTML-CSS-JS]. Mobil ve desktop tam uyumlu olsun. Kalici etki birakan tek bir fark yaratan detay belirle ve uygula.`

## 2) Emlak Ana Sayfa Tasarimi

`$frontend-design Emlak platformu icin ana sayfa tasarla. Odak: [SATILIK/KIRALIK/LUKS/YATIRIM]. Hero, hizli arama, one cikan ilanlar, guven unsurlari ve CTA bolumleri olsun. Cliche gorunumlerden kac, net bir estetik yon sec ve production-grade React kodu yaz.`

## 3) Ilan Listeleme + Filtreleme

`$frontend-design Ilan listeleme sayfasini yeniden tasarla. Sol tarafta filtre paneli, ustte akilli siralama, kart/grid gorunumu, mobilde sticky filtre tetigi olsun. Estetik yon: [EDITORIAL/BRUTALIST/LUXURY]. Performansli ve erisilebilir kod yaz.`

## 4) Ilan Detay Sayfasi

`$frontend-design Ilan detay sayfasi olustur. Buyuk gorsel galerisi, fiyat ve ozet bilgi alani, konum, ozellik listesi, danisman karti ve iletisim CTA'si olsun. Tasarim dili [TON], tipografi belirgin ve fark edilir olsun.`

## 5) Dashboard UI

`$frontend-design [ROL: emlak danismani/admin] icin dashboard tasarla. KPI kartlari, grafik alani, son aktiviteler, hizli aksiyon paneli olsun. Renk sistemi ve tipografi tutarli olsun, gereksiz kalabaliktan kac.`

## 6) Mevcut Bilesen Redesign

`$frontend-design Su bileseni yeniden tasarla: [BILESEN_ADI veya KOD]. Islevi bozma; sadece UX ve görsel kaliteyi yukari cek. 2 farkli estetik yon oner, sonra en guclu olani secip final kodunu ver.`

## 7) Form / Wizard Deneyimi

`$frontend-design [FORM_AMACI] icin cok adimli form (wizard) tasarla. Her adim acik, hata durumlari net, ilerleme gostergesi guclu olsun. Mikro-etkilesimlerle premium his ver ama akisi yavaslatma.`

## 8) Mobil-Once Tasarim

`$frontend-design Bu sayfayi mobile-first yaklasimla kur: [SAYFA_TANIMI]. Kucuk ekranda hiyerarsi, spacing ve dokunma alanlari kusursuz olsun. Sonra desktop icin zarif sekilde genislet.`

## 9) Erişilebilirlik Odakli UI

`$frontend-design [SAYFA/BILESEN] tasarlarken WCAG odakli ilerle. Kontrast, klavye navigasyonu, odak durumlari ve semantic HTML eksiksiz olsun. Estetikten odun verme, ama erisilebilirlikten asla taviz verme.`

## 10) Tipografi ve Renk Sistemi Kurulumu

`$frontend-design [PROJE_ADI] icin tipografi ve renk sistemi kur. CSS variable yapisi olustur, display/body font eslestir, durum renkleri (success/warning/error/info) ve spacing ritmini tanimla. Sonra kucuk bir demo section ile goster.`

## 11) Mikro-Animasyon Paketi

`$frontend-design [SAYFA/BILESEN] icin anlamli animasyonlar ekle: page-load reveal, hover states, scroll tetiklenen gecisler. Dikkat dagitmadan premium his versin. Motion stratejisini kisa aciklayip kodu uygula.`

## 12) "Kod + Gerekce" Ciktisi

`$frontend-design [SAYFA/BILESEN] tasarla ve kodla. Ciktiyi su formatta ver: 1) Tasarim yonu (kisa) 2) Tam kod 3) Neden bu secimleri yaptin 4) Istersen bir sonraki iterasyon onerileri.`

## 13) Hizli Iterasyon Komutu

`$frontend-design Bir onceki tasarimi 3 alternatif yone cevir: [YON_1], [YON_2], [YON_3]. En guclu alternatifi sec ve final kodunu ver.`

## 14) Duzeltme / Cilalama Komutu

`$frontend-design Bu mevcut kodu cilala: [KOD]. Islev ayni kalsin, ama tipografi, spacing, renk hiyerarsisi, hover/focus durumlari ve responsive davranis production seviyesine ciksin.`

## 15) Tam Paket Emlak Istegi

`$frontend-design Emlak sitesi icin tam bir on yuz akisi tasarla: ana sayfa, arama-sonuc, ilan detay, danisman profili ve mesajlasma girisi. Tek bir tutarli estetik dil kur; her sayfada ayni tasarim sistemi kullan. React + CSS module (veya tercih ettigin yapi) ile calisir kod uret.`
